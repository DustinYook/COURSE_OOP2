#include "point.h"

int main(void)
{
	cout << "Enter a point in the form (x, y):" << endl; 
	Point pt;
	cin >> pt;
	system("pause");
	return 0;
}