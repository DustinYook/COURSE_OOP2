#include "josephus.h"
using namespace std;

struct Node
{
	int seat;
	struct Node* next;
};

int main(void)
{
	Josephus j;
	struct Node* point = NULL;
	int winner, remove;

	j.insert(&point);
	cout << "The seat list is as follows" << endl;
	j.display(point);
	cout << "-------------------------------------------" << endl;
	cout << "Insert the person's number to be removed: ";
	cin >> remove;
	cout << "===========================================" << endl;
	winner = j.whoWins(&point, remove);
	cout << endl << "[Result] " << winner << " wins the game." << endl << endl;
	system("pause");
	return 0;
}