#include "josephus.h"

struct Node
{
	int seat;
	struct Node* next;
};

int Josephus::whoWins(struct Node** n, int k)
{
	struct Node *ptr1, *ptr2;
	ptr1 = ptr2 = *n;
	int cnt = 0;
	while (ptr1->next != ptr1)
	{
		if (cnt != 0)
			cout << "-> ";
		for (int i = 0; i < k - 1; i++)
		{
			ptr2 = ptr1;
			ptr1 = ptr1->next;
		} ptr2->next = ptr1->next;
		cout << ptr1->seat << " is removed ";
		if (cnt != 0 && cnt % 3 == 0)
			cout << endl;
		delete ptr1;
		ptr1 = ptr2->next;
		cnt++;
	} *n = ptr1;
	return (ptr1->seat);
}

void Josephus::insert(struct Node** n)
{
	struct Node *temp, *rear;
	int insert = 0;
	char answer = ' ';
	do
	{
		cout << "Insert a number: ";
		cin >> insert;
		temp = (struct Node*) new struct Node;
		temp->seat = insert;
		temp->next = NULL;
		if (*n == NULL)
			*n = temp;
		else
			rear->next = temp;
		rear = temp;
		cout << "Do you want to insert? [Y/N] => ";
		cin >> answer;
		cout << "----------------------------------" << endl;
	} while (answer != 'N' && answer != 'n');
	rear->next = *n;
}

void Josephus::display(struct Node* n)
{
	struct Node* temp;
	temp = n;
	cout << (temp->seat) << " ";
	temp = temp->next;
	while (n != temp)
	{
		cout << (temp->seat) << " ";
		temp = temp->next;
	} cout << endl;
}