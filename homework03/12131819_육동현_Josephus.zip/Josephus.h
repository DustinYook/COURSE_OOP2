#ifndef JOSEPHUS_H
#define JOSEPHUS_H
#include <iostream>
using namespace std;
class Josephus
{
public:
	void insert(struct Node**);
	void display(struct Node*);
	int whoWins(struct Node**, int);
};
#endif