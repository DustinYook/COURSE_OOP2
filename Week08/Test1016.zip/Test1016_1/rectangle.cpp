#include "rectangle.h"

int Rectangle::getArea()
{
	return (width*height);
}